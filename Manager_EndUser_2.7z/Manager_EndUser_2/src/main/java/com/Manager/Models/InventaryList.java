package com.Manager.Models;

import java.util.List;


public class InventaryList {
	
	private List<Inventary> allstaff;

	public List<Inventary> getAllstaff() {
		return allstaff;
	}

	public void setAllstaff(List<Inventary> allstaff) {
		this.allstaff = allstaff;
	}

}
